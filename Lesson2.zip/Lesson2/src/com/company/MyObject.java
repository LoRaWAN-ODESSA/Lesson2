package com.company;

public class MyObject {

    static int STATIC_NUMBER = 1;
    static String STATIC_STRING = "static string";

    int number;
    String text;
}
